import { useState, useRef, useCallback, useEffect } from "react";

/* ═══════════════════════════════════════════════════════════════════════
   PIXELFORGE  —  Professional Image Restoration & Enhancement
   Canvas-native · FastAPI Backend · Claude Vision AI
   ═══════════════════════════════════════════════════════════════════════ */

// ─── Color math ───────────────────────────────────────────────────────────────
const clamp = (v, lo = 0, hi = 255) => Math.max(lo, Math.min(hi, v));

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
  let h = 0, s = 0, l = (mx + mn) / 2;
  if (mx !== mn) {
    const d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (mx === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h /= 6;
  }
  return [h, s, l];
}

function hslToRgb(h, s, l) {
  if (!s) { const v = l * 255; return [v, v, v]; }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = t => { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1/6) return p+(q-p)*6*t; if (t < 1/2) return q; if (t < 2/3) return p+(q-p)*(2/3-t)*6; return p; };
  return [f(h+1/3)*255, f(h)*255, f(h-1/3)*255];
}

// ─── Canvas processing engine ─────────────────────────────────────────────────

function adjustPixels(id, { brightness:bri=0, contrast:con=0, saturation:sat=0, temperature:tmp=0, invertMode:inv="none" }) {
  const d = new Uint8ClampedArray(id.data);
  for (let i = 0; i < d.length; i += 4) {
    let r = d[i], g = d[i+1], b = d[i+2];
    if (bri) { r += bri*1.5; g += bri*1.5; b += bri*1.5; }
    if (con) { const f=(259*(con*2.55+255))/(255*(259-con*2.55)); r=f*(r-128)+128; g=f*(g-128)+128; b=f*(b-128)+128; }
    if (tmp) { r += tmp*0.32; b -= tmp*0.32; }
    if (sat) { const [h,s,l]=rgbToHsl(clamp(r),clamp(g),clamp(b)); [r,g,b]=hslToRgb(h,clamp(s+sat/100*0.85,0,1),l); }
    if (inv==="full")      { r=255-r; g=255-g; b=255-b; }
    else if (inv==="red")   r=255-r;
    else if (inv==="green") g=255-g;
    else if (inv==="blue")  b=255-b;
    d[i]=clamp(r); d[i+1]=clamp(g); d[i+2]=clamp(b);
  }
  return new ImageData(d, id.width, id.height);
}

function gaussBlur(id, radius=1) {
  const {data:d, width:w, height:h} = id;
  const size = radius*2+1, kernel=[]; let sum=0;
  for (let i=0;i<size;i++){const v=Math.exp(-((i-radius)**2)/(2*radius*radius)); kernel.push(v); sum+=v;}
  kernel.forEach((_,i)=>kernel[i]/=sum);
  const tmp=new Uint8ClampedArray(d), res=new Uint8ClampedArray(d);
  for (let y=0;y<h;y++) for (let x=0;x<w;x++) {
    let rr=0,gg=0,bb=0;
    for (let k=0;k<size;k++){const sx=Math.max(0,Math.min(w-1,x+k-radius)),ii=(y*w+sx)*4; rr+=d[ii]*kernel[k]; gg+=d[ii+1]*kernel[k]; bb+=d[ii+2]*kernel[k];}
    const oi=(y*w+x)*4; tmp[oi]=rr; tmp[oi+1]=gg; tmp[oi+2]=bb; tmp[oi+3]=d[oi+3];
  }
  for (let y=0;y<h;y++) for (let x=0;x<w;x++) {
    let rr=0,gg=0,bb=0;
    for (let k=0;k<size;k++){const sy=Math.max(0,Math.min(h-1,y+k-radius)),ii=(sy*w+x)*4; rr+=tmp[ii]*kernel[k]; gg+=tmp[ii+1]*kernel[k]; bb+=tmp[ii+2]*kernel[k];}
    const oi=(y*w+x)*4; res[oi]=rr; res[oi+1]=gg; res[oi+2]=bb; res[oi+3]=tmp[oi+3];
  }
  return new ImageData(res,w,h);
}

function sharpen(id, amount) {
  if (!amount) return id;
  const bl=gaussBlur(id,1), d=new Uint8ClampedArray(id.data), bd=bl.data, s=amount/100*2.1;
  for (let i=0;i<d.length;i+=4){d[i]=clamp(d[i]+s*(d[i]-bd[i])); d[i+1]=clamp(d[i+1]+s*(d[i+1]-bd[i+1])); d[i+2]=clamp(d[i+2]+s*(d[i+2]-bd[i+2]));}
  return new ImageData(d,id.width,id.height);
}

function bilateralDenoise(id, strength, edgePreserve=70) {
  if (!strength) return id;
  const {data:d, width:w, height:h}=id, res=new Uint8ClampedArray(d);
  const radius=Math.max(1,Math.ceil(strength/32));
  const sigC=strength*2.8*(1-(edgePreserve/100)*0.62), sigS=Math.max(1.5,radius*0.9);
  for (let y=0;y<h;y++) for (let x=0;x<w;x++) {
    const ci=(y*w+x)*4, cr=d[ci], cg=d[ci+1], cb=d[ci+2];
    let sr=0,sg=0,sb=0,sw=0;
    for (let dy=-radius;dy<=radius;dy++) for (let dx=-radius;dx<=radius;dx++){
      const ny=Math.max(0,Math.min(h-1,y+dy)), nx=Math.max(0,Math.min(w-1,x+dx)), ni=(ny*w+nx)*4;
      const wt=Math.exp(-(dx*dx+dy*dy)/(2*sigS*sigS)-((d[ni]-cr)**2+(d[ni+1]-cg)**2+(d[ni+2]-cb)**2)/(2*sigC*sigC));
      sr+=d[ni]*wt; sg+=d[ni+1]*wt; sb+=d[ni+2]*wt; sw+=wt;
    }
    const t=strength/100*0.92;
    res[ci]=clamp(cr*(1-t)+(sr/sw)*t); res[ci+1]=clamp(cg*(1-t)+(sg/sw)*t); res[ci+2]=clamp(cb*(1-t)+(sb/sw)*t);
  }
  return new ImageData(res,w,h);
}

function colorizeGray(id, warmth, vibrancy) {
  const d=new Uint8ClampedArray(id.data);
  for (let i=0;i<d.length;i+=4){
    const r=d[i],g=d[i+1],b=d[i+2];
    if (Math.abs(r-g)>16||Math.abs(g-b)>16) continue;
    const lum=0.299*r+0.587*g+0.114*b, l=lum/255;
    let nr,ng,nb;
    if (l<0.10)      {nr=lum*0.78;ng=lum*0.82;nb=lum*1.10;}
    else if (l<0.28) {nr=lum*1.06;ng=lum*0.97;nb=lum*0.78;}
    else if (l<0.55) {nr=lum*1.10;ng=lum*1.05;nb=lum*0.86;}
    else if (l<0.80) {nr=lum*1.07;ng=lum*1.03;nb=lum*0.91;}
    else             {nr=lum*1.04;ng=lum*1.01;nb=lum*0.97;}
    const w=(warmth-50)/100; nr=clamp(nr+w*30); nb=clamp(nb-w*24);
    const [h,s,lo]=rgbToHsl(clamp(nr),clamp(ng),clamp(nb));
    const [fr,fg,fb]=hslToRgb(h,clamp(s+(vibrancy/100)*0.48,0,1),lo);
    d[i]=clamp(fr); d[i+1]=clamp(fg); d[i+2]=clamp(fb);
  }
  return new ImageData(d,id.width,id.height);
}

function applyClarity(id, amount) {
  if (!amount) return id;
  const bl=gaussBlur(id,4), d=new Uint8ClampedArray(id.data), bd=bl.data, s=amount/100*0.6;
  for (let i=0;i<d.length;i+=4){
    const lum=(d[i]+d[i+1]+d[i+2])/3/255, boost=s*(1-Math.abs(lum-0.5)*2);
    d[i]=clamp(d[i]+boost*(d[i]-bd[i])); d[i+1]=clamp(d[i+1]+boost*(d[i+1]-bd[i+1])); d[i+2]=clamp(d[i+2]+boost*(d[i+2]-bd[i+2]));
  }
  return new ImageData(d,id.width,id.height);
}

function adjustShadowsHighlights(id, shadows, highlights) {
  if (!shadows&&!highlights) return id;
  const d=new Uint8ClampedArray(id.data);
  for (let i=0;i<d.length;i+=4){
    const lum=(d[i]+d[i+1]+d[i+2])/3/255;
    const sMask=Math.max(0,1-lum*3), hMask=Math.max(0,(lum-0.67)*3);
    for (let c=0;c<3;c++) d[i+c]=clamp(d[i+c]+shadows*1.2*sMask+highlights*1.0*hMask);
  }
  return new ImageData(d,id.width,id.height);
}

function bilinearUpscale(id, scale) {
  if (scale<=1) return id;
  const {data:d, width:w, height:h}=id, nw=Math.round(w*scale), nh=Math.round(h*scale), res=new Uint8ClampedArray(nw*nh*4);
  for (let y=0;y<nh;y++) for (let x=0;x<nw;x++){
    const gx=x/scale, gy=y/scale, x0=Math.floor(gx), y0=Math.floor(gy);
    const x1=Math.min(x0+1,w-1), y1=Math.min(y0+1,h-1), fx=gx-x0, fy=gy-y0, ri=(y*nw+x)*4;
    const i00=(y0*w+x0)*4, i10=(y0*w+x1)*4, i01=(y1*w+x0)*4, i11=(y1*w+x1)*4;
    for (let c=0;c<3;c++) res[ri+c]=clamp((d[i00+c]*(1-fx)+d[i10+c]*fx)*(1-fy)+(d[i01+c]*(1-fx)+d[i11+c]*fx)*fy);
    res[ri+3]=255;
  }
  return new ImageData(res,nw,nh);
}

// ─── UI primitives ────────────────────────────────────────────────────────────

const T = {
  bg:"#07070f", surface:"#0c0c1a", panel:"#0f0f1e", border:"#1a1a2e",
  accent:"#22d3ee", violet:"#7c3aed", green:"#10b981", amber:"#f59e0b",
  pink:"#ec4899", orange:"#f97316", text:"#e2e8f0", muted:"#475569", dim:"#252538",
};

function KnobSlider({label, value, min=0, max=100, step=1, unit="", onChange, color=T.accent}) {
  const pct=((value-min)/(max-min))*100, neutral=value===0;
  return (
    <div style={{marginBottom:13}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
        <span style={{fontSize:10.5,color:T.muted,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.07em"}}>{label}</span>
        <span style={{fontSize:11,fontFamily:"'JetBrains Mono',monospace",color:neutral?T.muted:color,fontWeight:600,minWidth:36,textAlign:"right"}}>
          {value>0&&min<0?"+":""}{value}{unit}
        </span>
      </div>
      <div style={{position:"relative",height:3,background:T.dim,borderRadius:99}}>
        {min<0
          ? <div style={{position:"absolute",left:`${Math.min(50,pct)}%`,top:0,height:"100%",width:`${Math.abs(pct-50)}%`,background:neutral?T.dim:`${color}80`,borderRadius:99}}/>
          : <div style={{position:"absolute",left:0,top:0,height:"100%",width:`${pct}%`,background:neutral?T.dim:`linear-gradient(90deg,${color}50,${color})`,borderRadius:99}}/>
        }
        {min<0&&<div style={{position:"absolute",left:"50%",top:"50%",transform:"translate(-50%,-50%)",width:1,height:7,background:T.muted}}/>}
        <input type="range" min={min} max={max} step={step} value={value} onChange={e=>onChange(parseFloat(e.target.value))}
          style={{position:"absolute",inset:0,width:"100%",height:"100%",opacity:0,cursor:"pointer",zIndex:3,margin:0,padding:0}}/>
        <div style={{position:"absolute",top:"50%",left:`${pct}%`,transform:"translate(-50%,-50%)",width:11,height:11,borderRadius:"50%",background:neutral?T.dim:color,boxShadow:neutral?"none":`0 0 7px ${color}88`,pointerEvents:"none",zIndex:2}}/>
      </div>
    </div>
  );
}

function Toggle({label, value, onChange, color=T.accent, note}) {
  return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12,gap:8}}>
      <div>
        <div style={{fontSize:10.5,color:T.muted,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.07em"}}>{label}</div>
        {note&&<div style={{fontSize:9.5,color:T.dim,marginTop:1,lineHeight:1.3}}>{note}</div>}
      </div>
      <div onClick={()=>onChange(!value)} style={{width:34,height:18,borderRadius:9,background:value?color:T.dim,cursor:"pointer",position:"relative",transition:"background 0.2s",flexShrink:0}}>
        <div style={{position:"absolute",top:2,left:value?16:2,width:14,height:14,borderRadius:"50%",background:"white",transition:"left 0.18s",boxShadow:"0 1px 4px #0009"}}/>
      </div>
    </div>
  );
}

function SLabel({children, color=T.violet}) {
  return <div style={{fontSize:9.5,color,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:9,marginTop:3}}>{children}</div>;
}
function HR() { return <div style={{height:1,background:T.border,margin:"13px 0"}}/>; }

function Chip({label, active, onClick, color=T.accent}) {
  return (
    <button onClick={onClick} style={{padding:"4px 9px",borderRadius:5,border:`1px solid ${active?color:T.border}`,background:active?`${color}18`:"transparent",color:active?color:T.muted,fontSize:10,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.04em",transition:"all 0.12s"}}>
      {label}
    </button>
  );
}

function ModelBadge({name, available, active}) {
  const c = available&&active ? T.green : available ? T.muted : T.dim;
  return (
    <div style={{display:"flex",alignItems:"center",gap:6,padding:"5px 8px",borderRadius:5,border:`1px solid ${available&&active?T.green+"35":T.border}`,background:available&&active?`${T.green}10`:"transparent",marginBottom:4}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:available?T.green:T.dim,flexShrink:0}}/>
      <span style={{fontSize:10,fontFamily:"'JetBrains Mono',monospace",color:c,flex:1,textTransform:"uppercase",letterSpacing:"0.05em"}}>{name}</span>
      <span style={{fontSize:9,color:available?T.green:T.dim,fontFamily:"'JetBrains Mono',monospace"}}>{available?"READY":"NOT LOADED"}</span>
    </div>
  );
}

// ─── Presets ──────────────────────────────────────────────────────────────────
const PRESETS = {
  portrait_antique:{label:"Antique Portrait",desc:"Warm, colorized, vintage",icon:"🎞",
    s:{brightness:-6,contrast:18,saturation:-15,temperature:26,sharpness:38,noiseReduction:48,edgePreservation:75,colorize:true,warmth:68,vibrancy:48,faceStrength:55}},
  maximize:{label:"Max Restore",desc:"Sharp · denoised · upscaled",icon:"⚡",
    s:{sharpness:72,noiseReduction:52,contrast:26,brightness:7,upscale:2,faceStrength:60,edgePreservation:72}},
  natural:{label:"Natural",desc:"Balanced, subtle, real",icon:"🌿",
    s:{sharpness:18,noiseReduction:18,contrast:7,brightness:2,preserveTexture:88,saturation:5,faceStrength:30,edgePreservation:82}},
  modernize:{label:"Modernize",desc:"Crisp, vivid, cool tone",icon:"✦",
    s:{sharpness:60,contrast:30,saturation:20,temperature:-16,brightness:5,faceStrength:52,noiseReduction:12}},
};

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [image,setImage]       = useState(null);
  const [processed,setProcessed] = useState(null);
  const [isDragging,setIsDragging] = useState(false);
  const [isProcessing,setIsProcessing] = useState(false);
  const [progress,setProgress] = useState(0);
  const [progressLabel,setProgressLabel] = useState("");
  const [panel,setPanel]       = useState("general");
  const [viewMode,setViewMode] = useState("slider");
  const [sliderPos,setSliderPos] = useState(50);
  const [sliderDrag,setSliderDrag] = useState(false);
  const [aiMsg,setAiMsg]       = useState("");
  const [aiLoading,setAiLoading] = useState(false);
  const [imgInfo,setImgInfo]   = useState(null);
  const [activePreset,setActivePreset] = useState(null);
  const [pipelineSteps,setPipelineSteps] = useState([]);
  const [procTime,setProcTime] = useState(null);

  // Backend state
  const [backendUrl,setBackendUrl]     = useState("http://localhost:8000");
  const [useBackend,setUseBackend]     = useState(false);
  const [bStatus,setBStatus]           = useState("unknown"); // unknown|checking|online|offline
  const [bModels,setBModels]           = useState({gfpgan:false,realesrgan:false,codeformer:false});
  const [useESRGAN,setUseESRGAN]       = useState(false);
  const [useGFPGAN,setUseGFPGAN]       = useState(false);
  const [useCodeFormer,setUseCodeFormer] = useState(false);
  const [bError,setBError]             = useState("");

  // Image settings
  const [S,setS] = useState({
    upscale:1, sharpness:0, brightness:0, contrast:0, saturation:0, temperature:0,
    faceStrength:50, eyeEnhance:40, skinSmooth:25, preserveTexture:80,
    colorize:false, warmth:50, vibrancy:50,
    invertMode:"none",
    noiseReduction:0, edgePreservation:72,
    shadows:0, highlights:0, clarity:0,
  });

  const cmpRef  = useRef(null);
  const fileRef = useRef(null);
  const timerRef = useRef(null);
  const st = (k,v) => { setS(p=>({...p,[k]:v})); setActivePreset(null); };

  // ── Backend health check ──────────────────────────────────────────────────
  const checkBackend = useCallback(async (url) => {
    const target = url ?? backendUrl;
    setBStatus("checking"); setBError("");
    try {
      const ctrl = new AbortController();
      const tout = setTimeout(()=>ctrl.abort(), 4000);
      const res = await fetch(`${target}/api/health`, {signal:ctrl.signal});
      clearTimeout(tout);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setBStatus("online");
      setBModels(data.models ?? {});
      if (data.models?.realesrgan) setUseESRGAN(true);
      if (data.models?.gfpgan)     setUseGFPGAN(true);
    } catch(e) {
      setBStatus("offline");
      setBModels({gfpgan:false,realesrgan:false,codeformer:false});
      setBError(e.name==="AbortError" ? "Timed out — is the backend running?" : e.message);
    }
  }, [backendUrl]);

  useEffect(()=>{ if (useBackend) checkBackend(); }, [useBackend]);

  // ── Comparison slider ─────────────────────────────────────────────────────
  useEffect(()=>{
    const move = e => {
      if (!sliderDrag||!cmpRef.current) return;
      const rect = cmpRef.current.getBoundingClientRect();
      setSliderPos(Math.max(2,Math.min(98,((( e.touches?.[0]??e).clientX-rect.left)/rect.width)*100)));
    };
    const up = ()=>setSliderDrag(false);
    window.addEventListener("mousemove",move); window.addEventListener("mouseup",up);
    window.addEventListener("touchmove",move,{passive:true}); window.addEventListener("touchend",up);
    return ()=>{ window.removeEventListener("mousemove",move); window.removeEventListener("mouseup",up); window.removeEventListener("touchmove",move); window.removeEventListener("touchend",up); };
  },[sliderDrag]);

  // ── File load ─────────────────────────────────────────────────────────────
  const loadFile = useCallback((file)=>{
    if (!file||!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = e => {
      setImage(e.target.result); setProcessed(null); setAiMsg("");
      setActivePreset(null); setPipelineSteps([]); setProcTime(null);
      const img=new Image();
      img.onload=()=>setImgInfo({w:img.width,h:img.height,kb:(file.size/1024).toFixed(0),name:file.name});
      img.src=e.target.result;
    };
    reader.readAsDataURL(file);
  },[]);

  // ── Canvas pipeline ───────────────────────────────────────────────────────
  const runCanvas = async () => {
    const img=new Image(); img.src=image;
    await new Promise(r=>img.onload=r);
    const canvas=document.createElement("canvas");
    canvas.width=img.width; canvas.height=img.height;
    canvas.getContext("2d").drawImage(img,0,0);
    const tick = async(lbl,pct)=>{ setProgressLabel(lbl); setProgress(pct); await new Promise(r=>setTimeout(r,10)); };
    let id = canvas.getContext("2d").getImageData(0,0,img.width,img.height);
    const steps=[];

    await tick("Reducing noise…",12);
    if (S.noiseReduction>0){id=bilateralDenoise(id,S.noiseReduction,S.edgePreservation); steps.push(`bilateral_denoise(${S.noiseReduction})`);}
    await tick("Shadows & Highlights…",24);
    if (S.shadows||S.highlights){id=adjustShadowsHighlights(id,S.shadows,S.highlights); steps.push("shadows_highlights");}
    await tick("Color corrections…",36);
    id=adjustPixels(id,S); steps.push("color_corrections");
    await tick("Colorizing…",50);
    if (S.colorize){id=colorizeGray(id,S.warmth,S.vibrancy); steps.push("luminance_colorize");}
    await tick("Clarity…",60);
    if (S.clarity>0){id=applyClarity(id,S.clarity); steps.push(`clarity(${S.clarity})`);}
    await tick("Upscaling…",68);
    if (S.upscale>1){id=bilinearUpscale(id,S.upscale); steps.push(`bilinear_x${S.upscale}`);}
    await tick("Sharpening…",80);
    if (S.sharpness>0){id=sharpen(id,S.sharpness); steps.push(`unsharp_mask(${S.sharpness})`);}
    await tick("Face enhancement…",90);
    if (S.faceStrength>0){
      const fe=sharpen(id,S.faceStrength*0.42), t=(S.faceStrength/100)*0.58;
      for(let i=0;i<id.data.length;i+=4){id.data[i]=id.data[i]*(1-t)+fe.data[i]*t; id.data[i+1]=id.data[i+1]*(1-t)+fe.data[i+1]*t; id.data[i+2]=id.data[i+2]*(1-t)+fe.data[i+2]*t;}
      steps.push(`canvas_face(${S.faceStrength})`);
    }
    await tick("Finalizing…",97);
    const out=document.createElement("canvas"); out.width=id.width; out.height=id.height;
    out.getContext("2d").putImageData(id,0,0);
    setProcessed(out.toDataURL("image/png",1.0));
    setPipelineSteps(steps); setProcTime(null);
  };

  // ── Backend pipeline ──────────────────────────────────────────────────────
  const runBackend = async () => {
    setBError("");
    // Animated fake progress while server works
    let fp=5;
    timerRef.current=setInterval(()=>{
      fp=Math.min(fp+(fp<35?3:fp<65?1.5:fp<85?0.7:0.25),92);
      setProgress(Math.round(fp));
      setProgressLabel(fp<20?"Sending image to FastAPI…":fp<40?"Bilateral denoising (OpenCV)…":fp<58?"Real-ESRGAN upscaling…":fp<75?"GFPGAN face restoration…":"Finalizing…");
    },260);

    try {
      const mime = image.startsWith("data:image/png")?"png":image.startsWith("data:image/webp")?"webp":"jpeg";
      const payload = {
        image,
        format:"png",
        upscale:S.upscale, sharpness:S.sharpness,
        brightness:S.brightness, contrast:S.contrast, saturation:S.saturation, temperature:S.temperature,
        face_strength:S.faceStrength, preserve_texture:S.preserveTexture,
        colorize:S.colorize, warmth:S.warmth, vibrancy:S.vibrancy,
        invert_mode:S.invertMode,
        noise_reduction:S.noiseReduction, edge_preservation:S.edgePreservation,
        shadows:S.shadows, highlights:S.highlights, clarity:S.clarity,
        use_realesrgan: useESRGAN && bModels.realesrgan,
        use_gfpgan:     useGFPGAN && bModels.gfpgan,
        use_codeformer: useCodeFormer && bModels.codeformer,
      };

      const res = await fetch(`${backendUrl}/api/process`,{
        method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload),
      });
      if (!res.ok){const e=await res.json().catch(()=>{}); throw new Error(e?.detail??`HTTP ${res.status}`);}
      const data = await res.json();
      clearInterval(timerRef.current);
      setProcessed(data.image);
      setPipelineSteps(data.pipeline_steps??[]);
      setProcTime(data.processing_time_ms);
    } catch(err) {
      clearInterval(timerRef.current);
      setBError(`Backend error: ${err.message} — falling back to canvas`);
      setProgressLabel("Backend failed, running canvas fallback…");
      await runCanvas();
    }
  };

  // ── Main dispatcher ───────────────────────────────────────────────────────
  const process = useCallback(async()=>{
    if (!image) return;
    clearInterval(timerRef.current);
    setIsProcessing(true); setProgress(0); setProcTime(null); setPipelineSteps([]);
    try {
      if (useBackend && bStatus==="online") await runBackend();
      else await runCanvas();
      setProgress(100); setProgressLabel("Complete!");
    } catch(e){ setProgressLabel("Error: "+e.message); }
    finally { setTimeout(()=>setIsProcessing(false),700); }
  },[image,S,useBackend,bStatus,backendUrl,useESRGAN,useGFPGAN,useCodeFormer,bModels]);

  // ── Claude AI ─────────────────────────────────────────────────────────────
  const aiAnalyze = async()=>{
    if (!image) return;
    setAiLoading(true); setAiMsg("");
    try{
      const b64=image.split(",")[1]??image;
      const mime=image.startsWith("data:image/png")?"image/png":image.startsWith("data:image/webp")?"image/webp":"image/jpeg";
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",max_tokens:800,
          messages:[{role:"user",content:[
            {type:"image",source:{type:"base64",media_type:mime,data:b64}},
            {type:"text",text:`Photo restoration expert. Return ONLY valid JSON:\n{"summary":"2 sentences","isGrayscale":bool,"mainIssues":["max 4"],"settings":{"brightness":-20to20,"contrast":0to40,"saturation":-25to35,"sharpness":0to75,"noiseReduction":0to65,"edgePreservation":55to90,"temperature":-25to25,"colorize":bool,"warmth":40to70,"vibrancy":30to65,"faceStrength":0to70,"clarity":0to50,"shadows":-20to20,"highlights":-20to20},"tip":"one tip to avoid artificial look"}`}
          ]}]
        }),
      });
      const data=await res.json(), txt=data.content?.[0]?.text??"{}";
      try{
        const p=JSON.parse(txt.replace(/```json|```/g,"").trim());
        setAiMsg((p.summary??"")+(p.tip?"\n\n💡 "+p.tip:"")+(p.mainIssues?.length?"\n\nIssues: "+p.mainIssues.join(", "):""));
        if(p.settings) setS(prev=>({...prev,...p.settings}));
      }catch{setAiMsg(txt.slice(0,400));}
    }catch{setAiMsg("AI analysis needs API access. Adjust sliders manually.");}
    setAiLoading(false);
  };

  const download=(fmt="png")=>{
    const src=processed??image; if(!src)return;
    const a=document.createElement("a"); a.href=src; a.download=`pixelforge.${fmt}`; a.click();
  };

  const applyPreset=id=>{ const p=PRESETS[id]; if(!p)return; setS(prev=>({...prev,...p.s})); setActivePreset(id); };
  const resetAll=()=>{ setS({upscale:1,sharpness:0,brightness:0,contrast:0,saturation:0,temperature:0,faceStrength:50,eyeEnhance:40,skinSmooth:25,preserveTexture:80,colorize:false,warmth:50,vibrancy:50,invertMode:"none",noiseReduction:0,edgePreservation:72,shadows:0,highlights:0,clarity:0}); setProcessed(null); setActivePreset(null); setPipelineSteps([]); setProcTime(null); };

  const SC={unknown:T.muted,checking:T.amber,online:T.green,offline:"#ef4444"};
  const SL={unknown:"Not connected",checking:"Checking…",online:"Online",offline:"Offline"};
  const panels=["general","faces","color","denoise","advanced","backend"];
  const activeModels=[useESRGAN&&bModels.realesrgan&&"ESRGAN",useGFPGAN&&bModels.gfpgan&&"GFPGAN",useCodeFormer&&bModels.codeformer&&"CodeFormer"].filter(Boolean);

  return (
    <div style={{height:"100vh",background:T.bg,color:T.text,fontFamily:"'Plus Jakarta Sans',sans-serif",display:"flex",flexDirection:"column",overflow:"hidden"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@300;400;500;600&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:#0c0c1a}::-webkit-scrollbar-thumb{background:#2a2a40;border-radius:2px}
        input[type=range]{-webkit-appearance:none;appearance:none;background:transparent;border:none;outline:none}
        input[type=text]{outline:none}
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes glow{0%,100%{box-shadow:0 0 20px #22d3ee1a}50%{box-shadow:0 0 35px #22d3ee33}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        .hov:hover{opacity:.8!important}
        .preset:hover{border-color:#22d3ee40!important;background:#22d3ee0a!important}
      `}</style>

      {/* ══ TOP BAR ════════════════════════════════════════════════════════ */}
      <div style={{height:52,background:T.surface,borderBottom:`1px solid ${T.border}`,display:"flex",alignItems:"center",padding:"0 14px",gap:8,flexShrink:0,zIndex:50}}>
        <div style={{display:"flex",alignItems:"center",gap:7,marginRight:"auto"}}>
          <div style={{width:26,height:26,borderRadius:6,background:`linear-gradient(135deg,${T.violet},${T.accent})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12}}>⬡</div>
          <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,letterSpacing:"-0.02em"}}>PIXEL<span style={{color:T.accent}}>FORGE</span></span>
          {imgInfo&&<span style={{fontSize:10,color:T.muted,fontFamily:"'JetBrains Mono',monospace",marginLeft:4}}>{imgInfo.w}×{imgInfo.h} · {imgInfo.kb}KB</span>}
        </div>

        {image&&<>
          {/* Invert chips */}
          <div style={{display:"flex",gap:3}}>
            {[["none","Off"],["full","Inv All"],["red","R"],["green","G"],["blue","B"]].map(([m,l])=>(
              <Chip key={m} label={l} active={S.invertMode===m} onClick={()=>st("invertMode",m)}/>
            ))}
          </div>
          <div style={{width:1,height:16,background:T.border}}/>
          <Chip label="🎨 Colorize" active={S.colorize} onClick={()=>st("colorize",!S.colorize)} color={T.violet}/>
          <div style={{width:1,height:16,background:T.border}}/>

          {/* Backend status pill */}
          <div onClick={()=>setPanel("backend")} style={{display:"flex",alignItems:"center",gap:5,padding:"3px 9px",borderRadius:99,border:`1px solid ${SC[bStatus]}28`,background:`${SC[bStatus]}0c`,cursor:"pointer"}}>
            <div style={{width:6,height:6,borderRadius:"50%",background:SC[bStatus],animation:bStatus==="checking"?"blink 0.8s infinite":"none"}}/>
            <span style={{fontSize:9.5,color:SC[bStatus],fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.05em"}}>
              {useBackend ? SL[bStatus] : "Canvas Mode"}
            </span>
          </div>
          <div style={{width:1,height:16,background:T.border}}/>

          <button onClick={aiAnalyze} disabled={aiLoading}
            style={{padding:"4px 11px",borderRadius:5,border:`1px solid ${T.green}45`,background:`${T.green}0f`,color:T.green,fontSize:10,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",letterSpacing:"0.06em",opacity:aiLoading?.6:1}}>
            {aiLoading?<span style={{animation:"pulse 1s infinite"}}>ANALYZING…</span>:"✦ AI ANALYZE"}
          </button>
          <div style={{width:1,height:16,background:T.border}}/>
          {["png","jpg","webp"].map(f=>(
            <button key={f} className="hov" onClick={()=>download(f)}
              style={{padding:"4px 8px",borderRadius:4,border:`1px solid ${T.accent}38`,background:`${T.accent}0c`,color:T.accent,fontSize:9.5,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",transition:"opacity .15s"}}>
              ↓ {f}
            </button>
          ))}
        </>}
      </div>

      {/* ══ BODY ═══════════════════════════════════════════════════════════ */}
      <div style={{flex:1,display:"flex",overflow:"hidden"}}>

        {/* ── LEFT PANEL ─────────────────────────────────────────────────── */}
        {image&&(
          <div style={{width:272,background:T.panel,borderRight:`1px solid ${T.border}`,display:"flex",flexDirection:"column",flexShrink:0}}>
            {/* Tabs */}
            <div style={{display:"flex",padding:"7px 6px 0",gap:1,background:T.surface,borderBottom:`1px solid ${T.border}`}}>
              {panels.map(p=>(
                <button key={p} onClick={()=>setPanel(p)} style={{flex:1,padding:"5px 0",border:"none",borderBottom:panel===p?`2px solid ${p==="backend"?SC[bStatus]:T.accent}`:"2px solid transparent",background:"transparent",color:panel===p?(p==="backend"?SC[bStatus]:T.accent):T.muted,fontSize:8.5,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.04em",fontWeight:panel===p?700:400,transition:"all 0.12s"}}>
                  {p==="backend"?(bStatus==="online"?"🟢 BE":"⚙ BE"):p.slice(0,3)}
                </button>
              ))}
            </div>

            {/* Content */}
            <div style={{flex:1,overflowY:"auto",padding:"13px 13px 6px"}}>

              {/* GENERAL */}
              {panel==="general"&&<>
                <SLabel>Upscale</SLabel>
                <div style={{display:"flex",gap:3,marginBottom:13}}>
                  {[1,2,4,6,8].map(v=>(
                    <button key={v} onClick={()=>st("upscale",v)} style={{flex:1,padding:"6px 0",borderRadius:5,border:`1px solid ${S.upscale===v?T.accent:T.border}`,background:S.upscale===v?`${T.accent}18`:"transparent",color:S.upscale===v?T.accent:T.muted,fontSize:11,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",transition:"all .12s"}}>
                      {v}×
                    </button>
                  ))}
                </div>
                <SLabel>Detail</SLabel>
                <KnobSlider label="Sharpness" value={S.sharpness} onChange={v=>st("sharpness",v)}/>
                <KnobSlider label="Clarity" value={S.clarity} onChange={v=>st("clarity",v)}/>
                <HR/>
                <SLabel>Exposure</SLabel>
                <KnobSlider label="Brightness" value={S.brightness} min={-50} max={50} onChange={v=>st("brightness",v)} color={T.amber}/>
                <KnobSlider label="Contrast"   value={S.contrast}   min={-50} max={50} onChange={v=>st("contrast",v)}   color={T.amber}/>
                <KnobSlider label="Shadows"    value={S.shadows}    min={-40} max={40} onChange={v=>st("shadows",v)}    color={T.amber}/>
                <KnobSlider label="Highlights" value={S.highlights} min={-40} max={40} onChange={v=>st("highlights",v)} color={T.amber}/>
                <HR/>
                <SLabel>Color</SLabel>
                <KnobSlider label="Saturation"   value={S.saturation}   min={-50} max={50} onChange={v=>st("saturation",v)}   color={T.pink}/>
                <KnobSlider label="Temperature"  value={S.temperature}  min={-50} max={50} onChange={v=>st("temperature",v)}  color={T.orange} unit="°"/>
              </>}

              {/* FACES */}
              {panel==="faces"&&<>
                <SLabel>Enhancement</SLabel>
                <KnobSlider label="Face Strength"    value={S.faceStrength}    onChange={v=>st("faceStrength",v)}    color={T.violet}/>
                <KnobSlider label="Eye Enhance"      value={S.eyeEnhance}      onChange={v=>st("eyeEnhance",v)}      color={T.violet}/>
                <HR/>
                <SLabel>Skin</SLabel>
                <KnobSlider label="Skin Smooth"      value={S.skinSmooth}      max={60} onChange={v=>st("skinSmooth",v)} color={T.pink}/>
                <KnobSlider label="Preserve Texture" value={S.preserveTexture} onChange={v=>st("preserveTexture",v)} color={T.green}/>
                <HR/>
                <div style={{padding:10,background:`${T.violet}0d`,border:`1px solid ${T.violet}20`,borderRadius:8,fontSize:11,color:T.muted,lineHeight:1.65}}>
                  <span style={{color:T.violet,fontWeight:600}}>Pro tip — </span>Keep Skin Smooth &lt;40 and Preserve Texture &gt;70. Enable GFPGAN or CodeFormer in the Backend tab for neural per-face restoration.
                </div>
              </>}

              {/* COLOR */}
              {panel==="color"&&<>
                <SLabel>B&W Colorization</SLabel>
                <Toggle label="Auto-Colorize" value={S.colorize} onChange={v=>st("colorize",v)} color={T.violet}
                  note={useBackend&&bStatus==="online"?"DeOldify/DDColor via backend":"Luminance-zone LUT (canvas)"}/>
                {S.colorize&&<>
                  <KnobSlider label="Warmth"   value={S.warmth}   onChange={v=>st("warmth",v)}   color={T.orange}/>
                  <KnobSlider label="Vibrancy" value={S.vibrancy} onChange={v=>st("vibrancy",v)} color={T.pink}/>
                </>}
                <HR/>
                <SLabel>Invert Channels</SLabel>
                <div style={{display:"flex",gap:4,flexWrap:"wrap",marginBottom:13}}>
                  {[["none","Off"],["full","All"],["red","R"],["green","G"],["blue","B"]].map(([m,l])=>(
                    <Chip key={m} label={l} active={S.invertMode===m} onClick={()=>st("invertMode",m)}/>
                  ))}
                </div>
              </>}

              {/* DENOISE */}
              {panel==="denoise"&&<>
                <SLabel>Bilateral Filter</SLabel>
                <KnobSlider label="Noise Reduction"  value={S.noiseReduction}  onChange={v=>st("noiseReduction",v)}/>
                <KnobSlider label="Edge Preservation" value={S.edgePreservation} onChange={v=>st("edgePreservation",v)} color={T.green}/>
                <HR/>
                <div style={{padding:10,background:`${T.accent}09`,border:`1px solid ${T.accent}1c`,borderRadius:8,fontSize:11,color:T.muted,lineHeight:1.65}}>
                  <div style={{color:T.accent,fontWeight:600,fontSize:10,fontFamily:"'JetBrains Mono',monospace",marginBottom:5}}>AVOIDING PLASTIC SKIN</div>
                  High Edge Preservation = tight color sigma → pores, hair and texture survive. Portrait sweet spot: Noise 20–50, Edge 68–85.
                </div>
                {useBackend&&bStatus==="online"&&<><HR/><div style={{fontSize:10.5,color:T.green,fontFamily:"'JetBrains Mono',monospace"}}>✓ Backend: OpenCV bilateral with adaptive sigma. BM3D-lite available with extra install.</div></>}
              </>}

              {/* ADVANCED */}
              {panel==="advanced"&&<>
                <SLabel>Tone Mapping</SLabel>
                <KnobSlider label="Shadows"    value={S.shadows}    min={-40} max={40} onChange={v=>st("shadows",v)}    color="#64748b"/>
                <KnobSlider label="Highlights" value={S.highlights} min={-40} max={40} onChange={v=>st("highlights",v)} color="#94a3b8"/>
                <KnobSlider label="Clarity"    value={S.clarity}    onChange={v=>st("clarity",v)}/>
                <HR/>
                <button onClick={resetAll} style={{width:"100%",padding:"8px 0",borderRadius:6,border:`1px solid ${T.border}`,background:"transparent",color:T.muted,fontSize:10,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.07em"}}>
                  ↺ Reset All Settings
                </button>
                {pipelineSteps.length>0&&<>
                  <HR/>
                  <SLabel>Last Pipeline</SLabel>
                  <div style={{display:"flex",flexDirection:"column",gap:3}}>
                    {pipelineSteps.map((s,i)=>(
                      <div key={i} style={{display:"flex",gap:6,alignItems:"center"}}>
                        <div style={{width:4,height:4,borderRadius:"50%",background:T.accent,flexShrink:0}}/>
                        <span style={{fontSize:10,fontFamily:"'JetBrains Mono',monospace",color:T.muted}}>{s}</span>
                      </div>
                    ))}
                    {procTime&&<div style={{fontSize:10,color:T.green,fontFamily:"'JetBrains Mono',monospace",marginTop:4}}>⏱ {procTime}ms on backend</div>}
                  </div>
                </>}
              </>}

              {/* ══ BACKEND PANEL ══ */}
              {panel==="backend"&&<>
                <SLabel color={T.green}>AI Backend</SLabel>

                <Toggle label="Enable AI Backend" value={useBackend} onChange={v=>{setUseBackend(v);if(v)checkBackend();}} color={T.green}
                  note="Auto-falls back to canvas if offline"/>

                {/* URL + test */}
                <div style={{marginBottom:13}}>
                  <div style={{fontSize:10.5,color:T.muted,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.07em",marginBottom:6}}>Backend URL</div>
                  <div style={{display:"flex",gap:5}}>
                    <input type="text" value={backendUrl} onChange={e=>setBackendUrl(e.target.value)}
                      placeholder="http://localhost:8000"
                      style={{flex:1,padding:"6px 8px",borderRadius:5,border:`1px solid ${bStatus==="online"?T.green+"50":T.border}`,background:T.surface,color:T.text,fontSize:11,fontFamily:"'JetBrains Mono',monospace"}}/>
                    <button onClick={()=>checkBackend()}
                      style={{padding:"6px 10px",borderRadius:5,border:`1px solid ${T.green}40`,background:`${T.green}10`,color:T.green,fontSize:10,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",whiteSpace:"nowrap"}}>
                      {bStatus==="checking"?<span style={{animation:"pulse .8s infinite"}}>…</span>:"TEST"}
                    </button>
                  </div>
                  {/* Status row */}
                  <div style={{display:"flex",alignItems:"center",gap:6,marginTop:7}}>
                    <div style={{width:7,height:7,borderRadius:"50%",background:SC[bStatus],animation:bStatus==="checking"?"blink .8s infinite":"none"}}/>
                    <span style={{fontSize:10.5,color:SC[bStatus],fontFamily:"'JetBrains Mono',monospace"}}>{SL[bStatus]}</span>
                  </div>
                  {bError&&<div style={{marginTop:5,fontSize:10,color:"#ef4444",fontFamily:"'JetBrains Mono',monospace",lineHeight:1.45}}>{bError}</div>}
                </div>

                <HR/>

                {/* Model cards */}
                <SLabel color={T.green}>AI Models</SLabel>
                <div style={{marginBottom:11}}>
                  <ModelBadge name="Real-ESRGAN  (Upscaling)" available={bModels.realesrgan} active={useESRGAN}/>
                  <ModelBadge name="GFPGAN v1.4  (Faces)"     available={bModels.gfpgan}     active={useGFPGAN}/>
                  <ModelBadge name="CodeFormer   (Faces)"     available={bModels.codeformer} active={useCodeFormer}/>
                </div>

                {bStatus==="online"&&<>
                  <Toggle label="Real-ESRGAN Upscaling" value={useESRGAN}     onChange={setUseESRGAN}     color={T.green}
                    note={bModels.realesrgan?"4x-UltraSharp quality":"Load model on backend first"}/>
                  <Toggle label="GFPGAN v1.4 Faces"     value={useGFPGAN}     onChange={setUseGFPGAN}     color={T.green}
                    note={bModels.gfpgan?"Full neural face restoration":"Load GFPGANv1.4.pth first"}/>
                  <Toggle label="CodeFormer Faces"       value={useCodeFormer} onChange={setUseCodeFormer} color={T.green}
                    note={bModels.codeformer?"Alternative face model":"Load CodeFormer weights first"}/>
                </>}

                <HR/>

                {/* Quick start */}
                <SLabel color={T.green}>Quick Start</SLabel>
                <div style={{padding:10,background:`${T.green}09`,border:`1px solid ${T.green}1e`,borderRadius:8,fontSize:11,color:T.muted,lineHeight:1.7}}>
                  <code style={{fontSize:9.5,display:"block",background:T.surface,padding:"7px 9px",borderRadius:5,color:T.accent,fontFamily:"'JetBrains Mono',monospace",lineHeight:1.9}}>
                    cd pixelforge-backend<br/>
                    pip install -r requirements.txt<br/>
                    python main.py
                  </code>
                  <div style={{marginTop:8,fontSize:10.5}}>For GPU models (optional):</div>
                  <code style={{fontSize:9.5,display:"block",background:T.surface,padding:"7px 9px",borderRadius:5,color:T.violet,fontFamily:"'JetBrains Mono',monospace",lineHeight:1.9,marginTop:4}}>
                    pip install torch basicsr gfpgan realesrgan<br/>
                    # Download weights → backend/weights/<br/>
                    # See README.md for URLs
                  </code>
                  <div style={{marginTop:8,fontSize:10,color:T.dim}}>Canvas mode works without any backend — backend unlocks Real-ESRGAN, GFPGAN, DeOldify.</div>
                </div>
              </>}

              {/* AI message */}
              {aiMsg&&(
                <div style={{marginTop:14,padding:10,background:`${T.green}0a`,border:`1px solid ${T.green}22`,borderRadius:8,animation:"fadeUp .3s ease"}}>
                  <div style={{fontSize:9.5,color:T.green,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:5,fontWeight:700}}>AI ANALYSIS</div>
                  <div style={{fontSize:11.5,color:"#94a3b8",lineHeight:1.7,whiteSpace:"pre-line"}}>{aiMsg}</div>
                  <div style={{fontSize:10,color:T.green,marginTop:6}}>↑ Settings auto-applied</div>
                </div>
              )}
            </div>

            {/* Presets */}
            <div style={{padding:"8px 13px",borderTop:`1px solid ${T.border}`}}>
              <div style={{fontSize:9.5,color:T.muted,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase",letterSpacing:"0.07em",marginBottom:6}}>Presets</div>
              <div style={{display:"flex",flexDirection:"column",gap:3}}>
                {Object.entries(PRESETS).map(([id,pr])=>(
                  <button key={id} onClick={()=>applyPreset(id)} className="preset"
                    style={{display:"flex",alignItems:"center",gap:7,padding:"6px 8px",borderRadius:6,border:`1px solid ${activePreset===id?T.accent:T.border}`,background:activePreset===id?`${T.accent}0f`:"transparent",color:T.text,fontSize:11,cursor:"pointer",textAlign:"left",transition:"all .12s"}}>
                    <span style={{fontSize:12}}>{pr.icon}</span>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600,fontSize:11,color:activePreset===id?T.accent:T.text}}>{pr.label}</div>
                      <div style={{fontSize:9.5,color:T.muted}}>{pr.desc}</div>
                    </div>
                    {activePreset===id&&<div style={{width:4,height:4,borderRadius:"50%",background:T.accent}}/>}
                  </button>
                ))}
              </div>
            </div>

            {/* Process button */}
            <div style={{padding:"10px 13px",borderTop:`1px solid ${T.border}`}}>
              {isProcessing?(
                <div>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                    <span style={{fontSize:10,color:T.muted,fontFamily:"'JetBrains Mono',monospace"}}>{progressLabel}</span>
                    <span style={{fontSize:10,color:T.accent,fontFamily:"'JetBrains Mono',monospace",fontWeight:600}}>{progress}%</span>
                  </div>
                  <div style={{height:4,background:T.dim,borderRadius:99,overflow:"hidden"}}>
                    <div style={{height:"100%",width:`${progress}%`,background:useBackend&&bStatus==="online"?`linear-gradient(90deg,${T.green},${T.accent})`:`linear-gradient(90deg,${T.violet},${T.accent})`,borderRadius:99,transition:"width .4s ease"}}/>
                  </div>
                </div>
              ):(
                <button onClick={process}
                  style={{width:"100%",padding:"11px 0",borderRadius:7,border:"none",background:useBackend&&bStatus==="online"?`linear-gradient(135deg,${T.green},${T.accent})`:`linear-gradient(135deg,${T.violet},${T.accent})`,color:"white",fontSize:11.5,fontWeight:700,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace",letterSpacing:"0.1em",textTransform:"uppercase",boxShadow:`0 4px 20px ${T.accent}20`,animation:"glow 3s ease infinite"}}>
                  {useBackend&&bStatus==="online"?"▶ AI PROCESS":"▶ PROCESS IMAGE"}
                </button>
              )}
              <div style={{textAlign:"center",marginTop:5,fontSize:9,color:T.dim,fontFamily:"'JetBrains Mono',monospace"}}>
                {useBackend&&bStatus==="online"
                  ?(activeModels.length?activeModels.join(" · "):"OPENCV")+" · FASTAPI"
                  :"CANVAS · BILATERAL · UNSHARP MASK"}
              </div>
            </div>
          </div>
        )}

        {/* ── CANVAS AREA ─────────────────────────────────────────────────── */}
        <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:image?16:40,overflow:"auto",background:T.bg}}>
          {!image?(
            <div onDragOver={e=>{e.preventDefault();setIsDragging(true);}} onDragLeave={()=>setIsDragging(false)}
              onDrop={e=>{e.preventDefault();setIsDragging(false);loadFile(e.dataTransfer.files[0]);}}
              onClick={()=>fileRef.current?.click()}
              style={{width:"100%",maxWidth:540,aspectRatio:"4/3",border:`1.5px dashed ${isDragging?T.accent:T.border}`,borderRadius:18,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:18,cursor:"pointer",transition:"all .2s",background:isDragging?`${T.accent}07`:"transparent",animation:isDragging?"glow 1.2s infinite":"none"}}>
              <div style={{width:72,height:72,borderRadius:14,background:`linear-gradient(135deg,${T.violet}28,${T.accent}28)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,animation:"fadeUp .5s ease"}}>⬡</div>
              <div style={{textAlign:"center",animation:"fadeUp .5s ease .1s both"}}>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:24,marginBottom:7,letterSpacing:"-0.02em"}}>Drop your image here</div>
                <div style={{color:T.muted,fontSize:13}}>or click to browse · JPG · PNG · WEBP · TIFF</div>
              </div>
              <div style={{display:"flex",gap:7,flexWrap:"wrap",justifyContent:"center",animation:"fadeUp .5s ease .2s both"}}>
                {["Real-ESRGAN","GFPGAN Faces","B&W Colorize","Bilateral Denoise","Invert Channels"].map(f=>(
                  <span key={f} style={{padding:"4px 11px",borderRadius:99,border:`1px solid ${T.border}`,fontSize:11,color:T.muted,fontFamily:"'JetBrains Mono',monospace"}}>{f}</span>
                ))}
              </div>
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,image/tiff" style={{display:"none"}} onChange={e=>loadFile(e.target.files[0])}/>
            </div>
          ):(
            <div style={{width:"100%",animation:"fadeUp .3s ease"}}>
              {/* View controls */}
              <div style={{display:"flex",gap:6,marginBottom:12,justifyContent:"center",alignItems:"center"}}>
                {[["slider","⇔ Slider"],["side","Side by Side"],["after","After Only"]].map(([m,l])=>(
                  <Chip key={m} label={l} active={viewMode===m} onClick={()=>setViewMode(m)}/>
                ))}
                <div style={{width:1,height:16,background:T.border}}/>
                <button onClick={()=>fileRef.current?.click()}
                  style={{padding:"4px 10px",borderRadius:5,border:`1px solid ${T.border}`,background:"transparent",color:T.muted,fontSize:10,cursor:"pointer",fontFamily:"'JetBrains Mono',monospace"}}>
                  New Image
                </button>
                <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>loadFile(e.target.files[0])}/>
              </div>

              {/* Side-by-side */}
              {viewMode==="side"&&(
                <div style={{display:"flex",gap:8}}>
                  {[["Before",image],["After",processed??image]].map(([lbl,src],idx)=>(
                    <div key={lbl} style={{flex:1,position:"relative"}}>
                      <img src={src} alt={lbl} style={{width:"100%",display:"block",borderRadius:8,border:`1px solid ${T.border}`}}/>
                      <div style={{position:"absolute",bottom:8,[idx===0?"left":"right"]:8,padding:"3px 8px",borderRadius:4,background:idx===1&&processed?`${T.accent}cc`:"#000a",fontSize:10,fontFamily:"'JetBrains Mono',monospace",color:"white"}}>{lbl}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* After only */}
              {viewMode==="after"&&(
                <div style={{position:"relative"}}>
                  <img src={processed??image} style={{width:"100%",maxHeight:"calc(100vh - 185px)",objectFit:"contain",display:"block",borderRadius:8,border:`1px solid ${T.border}`}} alt="Result"/>
                  {!processed&&<div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",background:"#0007",borderRadius:8}}>
                    <span style={{color:T.muted,fontFamily:"'JetBrains Mono',monospace",fontSize:11}}>Press PROCESS IMAGE to see result</span>
                  </div>}
                </div>
              )}

              {/* Comparison slider */}
              {viewMode==="slider"&&(
                <div ref={cmpRef} onMouseDown={()=>setSliderDrag(true)} onTouchStart={()=>setSliderDrag(true)}
                  style={{position:"relative",overflow:"hidden",borderRadius:9,border:`1px solid ${T.border}`,cursor:"ew-resize",userSelect:"none",maxHeight:"calc(100vh - 195px)"}}>
                  <img src={image} style={{width:"100%",maxHeight:"calc(100vh - 195px)",objectFit:"contain",display:"block"}} alt="Before" draggable={false}/>
                  {/* After image clipped to right side of slider */}
                  <div style={{position:"absolute",inset:0,clipPath:`inset(0 ${100-sliderPos}% 0 0)`,overflow:"hidden"}}>
                    <img src={processed??image} style={{width:"100%",height:"100%",objectFit:"contain",display:"block"}} alt="After" draggable={false}/>
                  </div>
                  {/* Handle */}
                  <div style={{position:"absolute",top:0,bottom:0,left:`${sliderPos}%`,transform:"translateX(-50%)",width:2,background:"rgba(255,255,255,.88)",boxShadow:"0 0 12px #0009",pointerEvents:"none"}}>
                    <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:30,height:30,borderRadius:"50%",background:"white",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 2px 12px #0006",color:"#222",fontSize:12,fontWeight:700}}>⇔</div>
                  </div>
                  <div style={{position:"absolute",bottom:9,left:9,padding:"3px 8px",background:"#000b",borderRadius:4,fontSize:10,fontFamily:"'JetBrains Mono',monospace",color:"#fff9",pointerEvents:"none"}}>BEFORE</div>
                  <div style={{position:"absolute",bottom:9,right:9,padding:"3px 8px",background:processed?(useBackend&&bStatus==="online"?`${T.green}cc`:`${T.accent}cc`):"#000b",borderRadius:4,fontSize:10,fontFamily:"'JetBrains Mono',monospace",color:"white",pointerEvents:"none"}}>
                    {processed?(useBackend&&bStatus==="online"?"AI ENHANCED":"ENHANCED"):"ORIGINAL"}
                  </div>
                </div>
              )}

              {/* Info bar */}
              {processed&&imgInfo&&(
                <div style={{marginTop:10,display:"flex",gap:16,justifyContent:"center",flexWrap:"wrap"}}>
                  {[
                    {l:"Original", v:`${imgInfo.w}×${imgInfo.h}`},
                    {l:"Output",   v:`${imgInfo.w*S.upscale}×${imgInfo.h*S.upscale}`},
                    {l:"Scale",    v:`${S.upscale}×`},
                    {l:"Sharp",    v:`${S.sharpness}%`},
                    {l:"Denoise",  v:`${S.noiseReduction}%`},
                    {l:"Engine",   v:useBackend&&bStatus==="online"?"FastAPI":"Canvas"},
                    ...(procTime?[{l:"Time",v:`${procTime}ms`}]:[]),
                  ].map(({l,v})=>(
                    <div key={l} style={{textAlign:"center"}}>
                      <div style={{fontSize:9.5,color:T.muted,fontFamily:"'JetBrains Mono',monospace",textTransform:"uppercase"}}>{l}</div>
                      <div style={{fontSize:12,color:T.accent,fontFamily:"'JetBrains Mono',monospace",fontWeight:600,marginTop:1}}>{v}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ══ STATUS BAR ════════════════════════════════════════════════════ */}
      <div style={{height:24,background:T.surface,borderTop:`1px solid ${T.border}`,display:"flex",alignItems:"center",padding:"0 14px",gap:14,flexShrink:0}}>
        <span style={{fontSize:9.5,color:T.muted,fontFamily:"'JetBrains Mono',monospace"}}>PIXELFORGE v1.1</span>
        <span style={{fontSize:9.5,color:T.dim,fontFamily:"'JetBrains Mono',monospace"}}>
          {useBackend&&bStatus==="online"
            ?`FastAPI · ${activeModels.length?activeModels.join(" · "):"OpenCV"} · Claude Vision`
            :"Canvas Engine · Bilateral Filter · Claude Vision · No upload · No tracking"}
        </span>
        {isProcessing&&<span style={{fontSize:9.5,color:T.accent,fontFamily:"'JetBrains Mono',monospace",animation:"pulse 1s infinite",marginLeft:"auto"}}>⬡ {progressLabel}</span>}
      </div>
    </div>
  );
}

# PixelForge — Deployment Guide
## GitHub + Vercel (frontend) + Railway (backend)

```
GitHub Repo
    ├── pixelforge-frontend/   → Vercel (React/Vite, free)
    └── pixelforge-backend/    → Railway (FastAPI, free tier)
```

---

## PASO 1 — Estructura del repositorio

Crea esta estructura de carpetas en tu máquina:

```
pixelforge/                     ← carpeta raíz del repo
├── .gitignore
├── README.md
├── railway.json
│
├── pixelforge-frontend/
│   ├── package.json
│   ├── vite.config.js
│   ├── vercel.json
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       └── App.jsx             ← pega aquí el contenido de PixelForge.jsx
│
└── pixelforge-backend/
    ├── main.py
    ├── requirements.txt
    ├── Dockerfile
    └── weights/                ← vacía, .gitignore la excluye
```

---

## PASO 2 — Crear el repositorio en GitHub

```bash
# En tu máquina, dentro de la carpeta raíz
cd pixelforge

git init
git add .
git commit -m "feat: initial PixelForge setup"

# Crea el repo en github.com/new  (nombre: pixelforge, público o privado)
git remote add origin https://github.com/TU_USUARIO/pixelforge.git
git branch -M main
git push -u origin main
```

---

## PASO 3 — Deploy del frontend en Vercel

### Opción A — Vercel CLI (recomendado)
```bash
npm install -g vercel

cd pixelforge-frontend
npm install        # instala react, vite
vercel             # sigue el wizard:
                   #  → Link to existing project? No
                   #  → Project name: pixelforge
                   #  → Root directory: ./  (ya estás en pixelforge-frontend)
                   #  → Override settings? No
vercel --prod      # deploy a producción
```

### Opción B — Vercel Dashboard (sin CLI)
1. Ve a **vercel.com** → Add New Project
2. Importa tu repo de GitHub `pixelforge`
3. En **Root Directory** escribe: `pixelforge-frontend`
4. Framework: **Vite** (auto-detectado)
5. Build Command: `npm run build`
6. Output Directory: `dist`
7. Clic en **Deploy**

Tu frontend queda en: `https://pixelforge-TU_USUARIO.vercel.app`

---

## PASO 4 — Deploy del backend en Railway

> Railway es gratis hasta 500 horas/mes (suficiente para testing y uso personal).
> Para modelos GPU pesados → upgrade a $5/mes o usa Render.

### 4.1 Crear proyecto en Railway
1. Ve a **railway.app** → New Project
2. **Deploy from GitHub repo** → selecciona `pixelforge`
3. Railway detecta el `railway.json` automáticamente
4. En **Root Directory**: `pixelforge-backend`
5. Railway construye el Dockerfile y despliega

### 4.2 Configurar variables de entorno (Railway)
En Settings → Variables, agrega si necesitas:
```
PORT=8000
PYTHONUNBUFFERED=1
```

### 4.3 Obtener la URL del backend
Railway asigna algo como:
`https://pixelforge-backend-production.up.railway.app`

---

## PASO 5 — Conectar frontend con backend

### Opción A — Variable de entorno en Vercel (recomendado)
En Vercel → Tu proyecto → Settings → Environment Variables:
```
VITE_BACKEND_URL = https://pixelforge-backend-production.up.railway.app
```

Luego en `src/App.jsx`, cambia la línea del estado inicial:
```jsx
// Antes (hardcoded):
const [backendUrl, setBackendUrl] = useState("http://localhost:8000");

// Después (lee la env var de Vercel):
const [backendUrl, setBackendUrl] = useState(
  import.meta.env.VITE_BACKEND_URL ?? "http://localhost:8000"
);
```

Haz redeploy:
```bash
vercel --prod
```

### Opción B — El usuario la pega manualmente
El campo de URL en el tab Backend ya permite que el usuario pegue su propia URL.
No hace falta cambiar nada en el código.

---

## PASO 6 — CORS: autorizar el frontend en el backend

En `pixelforge-backend/main.py`, el CORS ya está configurado con `allow_origins=["*"]`.
Para producción, cámbialo a tu dominio de Vercel:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://pixelforge-TU_USUARIO.vercel.app",
        "http://localhost:5173",   # dev local
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)
```

Haz commit + push y Railway redespliega automáticamente.

---

## Flujo de trabajo diario (dev local)

```bash
# Terminal 1 — Frontend
cd pixelforge/pixelforge-frontend
npm run dev
# → http://localhost:5173

# Terminal 2 — Backend
cd pixelforge/pixelforge-backend
pip install -r requirements.txt   # primera vez
python main.py
# → http://localhost:8000
# → docs en http://localhost:8000/docs
```

---

## Alternativas al backend en Railway

| Servicio         | GPU  | Free tier       | Ideal para          |
|------------------|------|-----------------|---------------------|
| **Railway**      | No*  | 500h/mes        | OpenCV, uso ligero  |
| **Render**       | No   | 750h/mes        | OpenCV, sin modelos |
| **Modal**        | ✓    | $30 crédito     | GFPGAN, ESRGAN      |
| **HF Spaces**    | ✓    | Free (GPU limitado) | Demo pública    |
| **Fly.io**       | No   | 3 VMs gratis    | Siempre activo      |
| **RunPod**       | ✓    | ~$0.20/hr       | Producción GPU      |

> Para usar Real-ESRGAN y GFPGAN en producción → **Modal** o **RunPod**.
> Para solo OpenCV (bilateral filter, sharpen, etc.) → **Railway** o **Render** son perfectos.

---

## Checklist final

- [ ] Repo en GitHub con la estructura correcta
- [ ] `PixelForge.jsx` pegado como `src/App.jsx` en el frontend
- [ ] Frontend desplegado en Vercel → URL pública funcionando
- [ ] Backend desplegado en Railway → `/api/health` responde `{"status":"ok"}`
- [ ] `VITE_BACKEND_URL` configurada en Vercel (o el usuario la pega en la UI)
- [ ] CORS actualizado con el dominio de Vercel en `main.py`
- [ ] Redeploy de ambos servicios tras los cambios

# PixelForge — Professional Image Restoration & Enhancement

A premium, standalone image restoration tool with canvas-native browser processing
and an optional Python backend for AI-powered enhancements (Real-ESRGAN, GFPGAN, etc).

```
┌─────────────────────────────────────────────────────┐
│   Frontend (React JSX artifact — runs in browser)   │
│   • Canvas-based processing (instant, no backend)   │
│   • Claude Vision AI analysis                       │
│   • All sliders, presets, compare slider            │
└──────────────────────┬──────────────────────────────┘
                       │ (optional) REST API
┌──────────────────────▼──────────────────────────────┐
│   Backend (Python/FastAPI)                          │
│   • Real-ESRGAN 4x-UltraSharp upscaling            │
│   • GFPGAN v1.4 / CodeFormer face restoration      │
│   • OpenCV bilateral denoising                      │
│   • DeOldify / DDColor colorization                 │
└─────────────────────────────────────────────────────┘
```

---

## Quick Start — Frontend Only

The React artifact runs entirely in the browser. No backend needed for:
- Brightness / Contrast / Saturation / Temperature
- Unsharp Mask sharpening
- Bilateral denoising (edge-preserving)
- Color inversion (full + per channel)
- Luminance-based B&W colorization
- Bilinear upscaling
- Before/After comparison slider
- Claude Vision AI analysis & auto-settings

---

## Backend Setup (AI-powered enhancements)

### 1. Install Python dependencies

```bash
cd pixelforge-backend

# Base dependencies (always required)
pip install -r requirements.txt

# GPU-accelerated AI models (optional but recommended)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install basicsr gfpgan realesrgan
```

### 2. Download model weights

```bash
mkdir -p weights

# GFPGAN v1.4 (face restoration)
wget -P weights https://github.com/TencentARC/GFPGAN/releases/download/v1.3.4/GFPGANv1.4.pth

# Real-ESRGAN x4+ (upscaling)
wget -P weights https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth

# 4x-UltraSharp (sharper than standard Real-ESRGAN, great for photos)
# Download from: https://openmodeldb.info/models/4x-UltraSharp
```

### 3. Run the backend

```bash
python main.py
# Server starts at http://localhost:8000
# Docs available at http://localhost:8000/docs
```

### 4. Connect frontend to backend

In the React artifact, update the `BACKEND_URL` constant:
```js
const BACKEND_URL = 'http://localhost:8000';
```
Then enable the **"Use AI Backend"** toggle in settings.

---

## API Reference

### POST /api/process
Full pipeline processing.

```json
{
  "image": "data:image/jpeg;base64,...",
  "upscale": 2,
  "sharpness": 60,
  "brightness": 5,
  "contrast": 20,
  "saturation": 10,
  "noise_reduction": 40,
  "edge_preservation": 75,
  "face_strength": 70,
  "colorize": false,
  "use_realesrgan": true,
  "use_gfpgan": true,
  "format": "png"
}
```

### GET /api/health
Returns model availability:
```json
{
  "status": "ok",
  "models": {
    "gfpgan": true,
    "realesrgan": true,
    "codeformer": false
  }
}
```

---

## Processing Pipeline (in order)

```
Input Image
    │
    ├── 1. Bilateral Denoise (edge-preserving, avoids plastic look)
    ├── 2. Brightness / Contrast
    ├── 3. Saturation / Temperature
    ├── 4. B&W Colorization (DeOldify / DDColor / luminance-LUT)
    ├── 5. Invert channels
    ├── 6. Upscale (Real-ESRGAN / Lanczos4)
    ├── 7. Face Restoration (GFPGAN v1.4 / OpenCV CLAHE)
    └── 8. Unsharp Mask Sharpening
         │
    Output Image
```

---

## Recommended Settings by Use Case

| Use Case          | Denoise | Sharp | Face | Upscale | Notes                    |
|-------------------|---------|-------|------|---------|--------------------------|
| Old B&W portrait  | 45      | 40    | 65   | 2x      | Enable colorize          |
| Damaged photo     | 60      | 35    | 50   | 2x      | High edge preservation   |
| Sharp modern      | 15      | 65    | 40   | 1x      | Low denoise, high sharp  |
| Low-light noisy   | 70      | 25    | 30   | 1x      | Edge preserve = 80       |
| Forensic upscale  | 20      | 80    | 0    | 4x      | Real-ESRGAN recommended  |

---

## Architecture Notes

### Avoiding the "Plastic/Wax" Look
The biggest enemy of photo restoration. Our approach:
1. **Bilateral filter** (not Gaussian) — respects edges, preserves texture
2. **Edge preservation slider** (0-100%) — higher = more texture kept
3. **Unsharp mask** after denoise — re-sharpens detail lost in smoothing
4. **Blend factor** on all operations — never 100% of any single filter

### Face Enhancement Naturalness
- GFPGAN `weight` parameter = face_strength / 100
- `preserve_texture` clips how much restoration is blended in
- Always `paste_back=True` — restores into original context

### B&W Colorization Quality
Browser: Luminance-zone LUT → good for quick preview
Backend: DeOldify artistic mode (render_factor=35) → production quality
Best: DDColor (2023) via ModelScope → state-of-the-art naturalness

---

## License
MIT — free for personal and commercial use.
AI model weights have their own licenses (check individual repos).

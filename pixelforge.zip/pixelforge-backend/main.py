"""
PixelForge Backend — FastAPI Image Restoration Server
======================================================
Endpoints:
  POST /api/process     → Full pipeline processing
  POST /api/upscale     → Upscaling only (Real-ESRGAN)
  POST /api/restore     → Face restoration (CodeFormer/GFPGAN)
  POST /api/colorize    → B&W colorization (DeOldify/DDColor)
  POST /api/denoise     → Denoising (bilateral + BM3D-lite)
  GET  /api/health      → Health check
"""

import io
import base64
import tempfile
import os
import time
import logging
from typing import Optional, Literal

import numpy as np
import cv2
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from PIL import Image, ImageEnhance, ImageFilter

# ── Optional heavy-model imports (install separately) ─────────────────────────
# These models require GPU for best performance.
# pip install basicsr gfpgan realesrgan torch torchvision
try:
    from gfpgan import GFPGANer
    GFPGAN_AVAILABLE = True
except ImportError:
    GFPGAN_AVAILABLE = False

try:
    from basicsr.archs.rrdbnet_arch import RRDBNet
    from realesrgan import RealESRGANer
    REALESRGAN_AVAILABLE = True
except ImportError:
    REALESRGAN_AVAILABLE = False

try:
    from codeformer.basicsr.utils.registry import ARCH_REGISTRY
    CODEFORMER_AVAILABLE = True
except ImportError:
    CODEFORMER_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("pixelforge")

app = FastAPI(title="PixelForge API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Lazy-loaded models ─────────────────────────────────────────────────────────
_gfpgan = None
_realesrgan = None
_codeformer = None

def get_gfpgan():
    global _gfpgan
    if _gfpgan is None and GFPGAN_AVAILABLE:
        _gfpgan = GFPGANer(
            model_path='weights/GFPGANv1.4.pth',
            upscale=1,
            arch='clean',
            channel_multiplier=2,
            bg_upsampler=None,
        )
    return _gfpgan

def get_realesrgan(scale=4):
    global _realesrgan
    if _realesrgan is None and REALESRGAN_AVAILABLE:
        model = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64, num_block=23, num_grow_ch=32, scale=4)
        _realesrgan = RealESRGANer(
            scale=scale,
            model_path='weights/RealESRGAN_x4plus.pth',
            model=model,
            tile=512,          # Tile to avoid OOM
            tile_pad=10,
            pre_pad=0,
            half=False,
        )
    return _realesrgan

# ── Request / Response schemas ────────────────────────────────────────────────

class ProcessRequest(BaseModel):
    image: str                          # base64-encoded image
    format: Literal['jpeg','png','webp'] = 'png'

    # General
    upscale: float = Field(1.0, ge=1.0, le=8.0)
    sharpness: float = Field(0.0, ge=0.0, le=100.0)
    brightness: float = Field(0.0, ge=-50.0, le=50.0)
    contrast: float = Field(0.0, ge=-50.0, le=50.0)
    saturation: float = Field(0.0, ge=-50.0, le=50.0)
    temperature: float = Field(0.0, ge=-50.0, le=50.0)

    # Faces
    face_strength: float = Field(0.0, ge=0.0, le=100.0)
    preserve_texture: float = Field(80.0, ge=0.0, le=100.0)
    use_codeformer: bool = False

    # Color
    colorize: bool = False
    warmth: float = Field(50.0, ge=0.0, le=100.0)
    vibrancy: float = Field(50.0, ge=0.0, le=100.0)
    invert_mode: Literal['none','full','red','green','blue'] = 'none'

    # Denoise
    noise_reduction: float = Field(0.0, ge=0.0, le=100.0)
    edge_preservation: float = Field(70.0, ge=0.0, le=100.0)

    # Advanced
    use_realesrgan: bool = False        # Use Real-ESRGAN for upscaling
    use_gfpgan: bool = False            # Use GFPGAN for face enhancement

class ProcessResponse(BaseModel):
    image: str                          # base64-encoded result
    width: int
    height: int
    processing_time_ms: int
    pipeline_steps: list[str]


# ── Pure-OpenCV/NumPy processing (always available) ──────────────────────────

def decode_b64_image(b64: str) -> np.ndarray:
    """Decode base64 → BGR numpy array."""
    b64 = b64.split(',')[-1]            # strip data-URL prefix
    raw = base64.b64decode(b64)
    arr = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Cannot decode image")
    return img

def encode_image_b64(img: np.ndarray, fmt='png') -> str:
    """BGR numpy → base64 data-URL."""
    ext = '.png' if fmt == 'png' else '.webp' if fmt == 'webp' else '.jpg'
    params = [cv2.IMWRITE_JPEG_QUALITY, 95] if fmt == 'jpeg' else []
    ok, buf = cv2.imencode(ext, img, params)
    if not ok:
        raise ValueError("Cannot encode image")
    b64 = base64.b64encode(buf.tobytes()).decode()
    mime = 'image/png' if fmt == 'png' else 'image/webp' if fmt == 'webp' else 'image/jpeg'
    return f"data:{mime};base64,{b64}"

def adjust_brightness_contrast(img: np.ndarray, brightness: float, contrast: float) -> np.ndarray:
    """Brightness (-50→50) and contrast (-50→50) via CLAHE-aware linear transform."""
    img = img.astype(np.float32)
    if brightness != 0:
        img += brightness * 1.5
    if contrast != 0:
        factor = (259 * (contrast * 2.55 + 255)) / (255 * (259 - contrast * 2.55))
        img = factor * (img - 128) + 128
    return np.clip(img, 0, 255).astype(np.uint8)

def adjust_saturation(img: np.ndarray, saturation: float) -> np.ndarray:
    """Saturation adjustment in HSV space."""
    if saturation == 0:
        return img
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[..., 1] = np.clip(hsv[..., 1] + saturation / 100 * 85, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

def adjust_temperature(img: np.ndarray, temperature: float) -> np.ndarray:
    """Warm/cool color temperature shift."""
    if temperature == 0:
        return img
    img = img.astype(np.float32)
    t = temperature * 0.35
    img[..., 2] = np.clip(img[..., 2] + t, 0, 255)  # Red channel (BGR)
    img[..., 0] = np.clip(img[..., 0] - t, 0, 255)  # Blue channel
    return img.astype(np.uint8)

def apply_sharpening(img: np.ndarray, amount: float) -> np.ndarray:
    """Unsharp mask sharpening — preserves texture."""
    if amount <= 0:
        return img
    sigma = 1.0
    blurred = cv2.GaussianBlur(img, (0, 0), sigma)
    strength = amount / 100 * 2.0
    sharpened = cv2.addWeighted(img, 1 + strength, blurred, -strength, 0)
    return np.clip(sharpened, 0, 255).astype(np.uint8)

def apply_bilateral_denoise(img: np.ndarray, strength: float, edge_preserve: float) -> np.ndarray:
    """
    Bilateral filter — edge-aware denoising.
    High edge_preserve → narrow color tolerance → preserves texture, avoids plastic look.
    """
    if strength <= 0:
        return img
    d = max(3, int(strength / 25) * 2 + 3)          # filter diameter
    sigma_color = strength * 2.5 * (1 - edge_preserve / 100 * 0.6)
    sigma_space = max(2, d / 2)
    
    # Multiple passes with smaller params for more control
    passes = 1 if strength < 40 else 2
    result = img.copy()
    for _ in range(passes):
        result = cv2.bilateralFilter(result, d, sigma_color, sigma_space)
    
    # Blend with original for texture preservation
    t = strength / 100 * (0.7 + edge_preserve / 100 * 0.3)
    return cv2.addWeighted(img, 1 - t, result, t, 0)

def apply_invert(img: np.ndarray, mode: str) -> np.ndarray:
    if mode == 'none':
        return img
    result = img.copy()
    if mode == 'full':
        result = 255 - result
    elif mode == 'red':
        result[..., 2] = 255 - result[..., 2]
    elif mode == 'green':
        result[..., 1] = 255 - result[..., 1]
    elif mode == 'blue':
        result[..., 0] = 255 - result[..., 0]
    return result

def colorize_grayscale(img: np.ndarray, warmth: float, vibrancy: float) -> np.ndarray:
    """
    Luminance-based colorization.
    
    NOTE: For production quality, replace with DDColor or DeOldify:
      pip install deoldify
      from deoldify.visualize import get_image_colorizer
      colorizer = get_image_colorizer(artistic=True)
      result = colorizer.get_transformed_image(path, render_factor=35)
    """
    # Check if already color
    b, g, r = cv2.split(img.astype(np.float32))
    if np.mean(np.abs(r - g)) > 15 or np.mean(np.abs(g - b)) > 15:
        return img  # Already color

    # Convert to Lab for natural colorization
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)
    lab = np.zeros((img.shape[0], img.shape[1], 3), dtype=np.float32)
    lab[..., 0] = gray / 255 * 100  # L channel

    # Natural ab channels based on luminance zones
    lum = gray / 255
    a_ch = np.zeros_like(lum)
    b_ch = np.zeros_like(lum)

    # Shadows → cool blue
    mask_shadow = lum < 0.12
    a_ch[mask_shadow] = -2; b_ch[mask_shadow] = -8

    # Dark midtones → warm brown
    mask_dark = (lum >= 0.12) & (lum < 0.30)
    a_ch[mask_dark] = 5; b_ch[mask_dark] = 12

    # Midtones → natural warm
    mask_mid = (lum >= 0.30) & (lum < 0.60)
    a_ch[mask_mid] = 8; b_ch[mask_mid] = 18

    # Light midtones → skin/sky
    mask_light = (lum >= 0.60) & (lum < 0.82)
    a_ch[mask_light] = 6; b_ch[mask_light] = 12

    # Highlights → very warm
    mask_hi = lum >= 0.82
    a_ch[mask_hi] = 3; b_ch[mask_hi] = 6

    # Apply warmth shift
    w = (warmth - 50) / 100
    b_ch += w * 15
    a_ch += w * 5

    # Apply vibrancy
    v = vibrancy / 100
    a_ch *= (1 + v * 1.5)
    b_ch *= (1 + v * 1.5)

    lab[..., 1] = np.clip(a_ch + 128, 0, 255)
    lab[..., 2] = np.clip(b_ch + 128, 0, 255)

    result = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2BGR)
    # Blend lightly with grayscale for naturalness
    return cv2.addWeighted(result, 0.85, img, 0.15, 0)

def upscale_opencv(img: np.ndarray, scale: float) -> np.ndarray:
    """
    Lanczos4 upscaling (high-quality interpolation).
    
    NOTE: Replace with Real-ESRGAN for production:
      model = get_realesrgan(scale=4)
      output, _ = model.enhance(img, outscale=scale)
    """
    if scale <= 1.0:
        return img
    new_w = int(img.shape[1] * scale)
    new_h = int(img.shape[0] * scale)
    return cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)

def enhance_faces_opencv(img: np.ndarray, strength: float, preserve_texture: float) -> np.ndarray:
    """
    Face-aware local enhancement using Haar cascade (approximate).
    
    NOTE: Replace with GFPGAN/CodeFormer for production:
      gfp = get_gfpgan()
      _, _, output = gfp.enhance(img, has_aligned=False, only_center_face=False,
                                  paste_back=True, weight=strength/100)
    """
    if strength <= 0:
        return img
    
    # Detect faces
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    
    result = img.copy()
    for (x, y, w, h) in faces:
        # Expand ROI slightly
        pad = int(max(w, h) * 0.1)
        x1 = max(0, x - pad); y1 = max(0, y - pad)
        x2 = min(img.shape[1], x + w + pad); y2 = min(img.shape[0], y + h + pad)
        face_roi = result[y1:y2, x1:x2]
        
        # Local contrast enhancement (CLAHE on luminance)
        lab = cv2.cvtColor(face_roi, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clip_limit = 1.5 + (strength / 100) * 2.0
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(4, 4))
        l = clahe.apply(l)
        face_enhanced = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
        
        # Sharpen face
        face_enhanced = apply_sharpening(face_enhanced, strength * 0.5)
        
        # Light denoise preserving texture
        if preserve_texture < 80:
            smooth_str = (1 - preserve_texture / 100) * 30
            face_enhanced = apply_bilateral_denoise(face_enhanced, smooth_str, 80)
        
        # Blend
        t = strength / 100 * 0.7
        result[y1:y2, x1:x2] = cv2.addWeighted(face_roi, 1 - t, face_enhanced, t, 0)
    
    if len(faces) == 0:
        # No face detected: apply gentle global enhancement
        result = apply_sharpening(result, strength * 0.3)
    
    return result


# ── API endpoints ─────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "models": {
            "gfpgan": GFPGAN_AVAILABLE,
            "realesrgan": REALESRGAN_AVAILABLE,
            "codeformer": CODEFORMER_AVAILABLE,
        }
    }

@app.post("/api/process", response_model=ProcessResponse)
async def process_image(req: ProcessRequest):
    t0 = time.time()
    steps = []
    
    try:
        img = decode_b64_image(req.image)
    except Exception as e:
        raise HTTPException(400, f"Invalid image: {e}")
    
    # ── Pipeline ──────────────────────────────────────────────────────────────

    # 1. Denoise (at original resolution for efficiency)
    if req.noise_reduction > 0:
        img = apply_bilateral_denoise(img, req.noise_reduction, req.edge_preservation)
        steps.append(f"bilateral_denoise(strength={req.noise_reduction:.0f}, edge={req.edge_preservation:.0f})")

    # 2. Color corrections
    if req.brightness != 0 or req.contrast != 0:
        img = adjust_brightness_contrast(img, req.brightness, req.contrast)
        steps.append(f"brightness_contrast(b={req.brightness:.0f}, c={req.contrast:.0f})")
    
    if req.saturation != 0:
        img = adjust_saturation(img, req.saturation)
        steps.append(f"saturation({req.saturation:.0f})")
    
    if req.temperature != 0:
        img = adjust_temperature(img, req.temperature)
        steps.append(f"temperature({req.temperature:.0f})")

    # 3. Colorization
    if req.colorize:
        img = colorize_grayscale(img, req.warmth, req.vibrancy)
        steps.append("colorize_grayscale")

    # 4. Invert
    if req.invert_mode != 'none':
        img = apply_invert(img, req.invert_mode)
        steps.append(f"invert_{req.invert_mode}")

    # 5. Upscale
    if req.upscale > 1.0:
        if req.use_realesrgan and REALESRGAN_AVAILABLE:
            try:
                esrgan = get_realesrgan(scale=4)
                img, _ = esrgan.enhance(img, outscale=req.upscale)
                steps.append(f"realesrgan_x{req.upscale:.0f}")
            except Exception as e:
                log.warning(f"Real-ESRGAN failed: {e}. Falling back to Lanczos4.")
                img = upscale_opencv(img, req.upscale)
                steps.append(f"lanczos4_x{req.upscale:.1f}")
        else:
            img = upscale_opencv(img, req.upscale)
            steps.append(f"lanczos4_x{req.upscale:.1f}")

    # 6. Face enhancement (after upscale)
    if req.face_strength > 0:
        if req.use_gfpgan and GFPGAN_AVAILABLE:
            try:
                gfp = get_gfpgan()
                _, _, output = gfp.enhance(
                    img,
                    has_aligned=False,
                    only_center_face=False,
                    paste_back=True,
                    weight=req.face_strength / 100,
                )
                img = output
                steps.append(f"gfpgan(strength={req.face_strength:.0f})")
            except Exception as e:
                log.warning(f"GFPGAN failed: {e}. Falling back to OpenCV.")
                img = enhance_faces_opencv(img, req.face_strength, req.preserve_texture)
                steps.append(f"opencv_face(strength={req.face_strength:.0f})")
        else:
            img = enhance_faces_opencv(img, req.face_strength, req.preserve_texture)
            steps.append(f"opencv_face(strength={req.face_strength:.0f})")

    # 7. Sharpening (final pass)
    if req.sharpness > 0:
        img = apply_sharpening(img, req.sharpness)
        steps.append(f"unsharp_mask({req.sharpness:.0f})")

    # ── Encode result ─────────────────────────────────────────────────────────
    h, w = img.shape[:2]
    result_b64 = encode_image_b64(img, req.format)
    elapsed_ms = int((time.time() - t0) * 1000)
    
    log.info(f"Processed {w}×{h} in {elapsed_ms}ms | Steps: {steps}")
    
    return ProcessResponse(
        image=result_b64,
        width=w, height=h,
        processing_time_ms=elapsed_ms,
        pipeline_steps=steps,
    )


@app.post("/api/upscale")
async def upscale_only(req: ProcessRequest):
    """Dedicated upscaling endpoint (Real-ESRGAN when available)."""
    img = decode_b64_image(req.image)
    scale = max(1.0, req.upscale)
    
    if req.use_realesrgan and REALESRGAN_AVAILABLE:
        try:
            esrgan = get_realesrgan()
            img, _ = esrgan.enhance(img, outscale=scale)
        except Exception:
            img = upscale_opencv(img, scale)
    else:
        img = upscale_opencv(img, scale)
    
    return {"image": encode_image_b64(img, req.format), "width": img.shape[1], "height": img.shape[0]}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
